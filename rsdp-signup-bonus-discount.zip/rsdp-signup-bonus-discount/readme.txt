=== Search Notification ===
Contributors: deepak vishwakarma
Donate link: http://rsdptechnologies.in/
Tags: woocommerce,  Signup Bonus Discount, rsdp, RSDP Signup Bonus Discount
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Give a signup bonus discount for new users.
== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/rsdp-signup-bonus-discount` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the shortcode `[signup-bonus]` to display the search form on any page or post.

== Frequently Asked Questions ==

= How do I use this plugin? =

Simply use the shortcode `[signup-bonus]` to display the Signup Bonus Discount.


== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
Initial release.

== Screenshots ==

1. Signup Bonus Discount.

== License ==

This plugin is licensed under the GPLv2 or later. See the LICENSE file for details.
